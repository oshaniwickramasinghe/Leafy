<html>  
<head>  
    <title>insert successful</title>  
    <link rel = "stylesheet" type = "text/css" href = "style.css"> 
</head>  
<body>  

    <div class="header">
            <h1>Leafy</h1>   
    </div>

        <div><h2>insert successful</h2></div>
        
    <div class="footer">
        <p>Click here to go to home page
            <a href="home.php">
                <button id="logout">Home</button>
            </a>
        </p>
    </div>

</body>     
</html>  