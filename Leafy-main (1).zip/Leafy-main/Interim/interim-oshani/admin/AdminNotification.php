<html>  
<head>  
    <title>Admin Notification</title>  
    <link rel = "stylesheet" type = "text/css" href ='home.css'>   
</head>  

<body>  

<?php include 'home.php';?>

    <div class="div1">
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
        <div class="div2">
        <h2>some text</h2>
            <h2>some words</h2>
        </div>
            

    </div>

    
    
</body>     
</html>  