<?php
include "nav.php";

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Home</title>
    <link rel="stylesheet" href="logged.css">
    <link rel="stylesheet" 
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class  = "shopping">
    <i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>
        <button class = "cart" onclick="document.location='shopping_cart.php'"> Cart </button>
     </div>

 <div class = "container_1">
    
 <img src = "images/vegetable.png" class = "image_1">
 <button class="btnn">Vegetables & Fruits</button>
</div>

<div class = "container_2">
<img src = "images/seed.png" class = "image_2">
 <button class="btnn">Seeds</button>
</div>

<div class = "container_3">
<img src = "images/courses.png" class = "image_3">
 <button class="btnn">Courses</button>
</div>

<div class = "container_4">
<img src = "images/blog.png" class = "image_4">
 <button class="btnn">Blog</button>
</div>



</body>

 

</html>

